<li>
    <div class="main doc">

        <div class="queto"> 
            <img src="http://localhost/lgphp/images/top_qeto.png" alt="asumit">
        </div>

        <div class="right_icon">
            <a href="javascript:void(0);" class="icon-btn" title="Delete"><i class="fa fa-trash"></i></a>
            <a href="javascript:void(0);" class="icon-btn" title="Inactive"><i class="fa fa-close"></i></a>
            <a href="javascript:void(0);" class="icon-btn" title="Active"><i class="fa fa-check"></i></a>

            <img src="http://localhost/lgphp/images/doc.png" alt="asumit">

        </div>
        <div class="name">
            asumit                        </div>
        <div class="tag">
            #KarSallam
        </div>
        <p>faedrwerqwerq wer</p>

    </div>
</li>



<li>
    <div class="main doc">
        <div class="queto">
            <img src="http://localhost/lgphp/images/top_qeto.png" alt="asdfads">
        </div>
        <div class="right_icon">
            <a href="javascript:void(0);" class="icon-btn" title="Delete">
                <i class="fa fa-trash"></i>
            </a>
            <a href="javascript:void(0);" class="icon-btn" title="Inactive">
                <i class="fa fa-close"></i>
            </a>
            <a href="javascript:void(0);" class="icon-btn" title="Active">
                <i class="fa fa-check"></i>
            </a>
            <img src="http://localhost/lgphp/images/doc.png" alt="asdfads">
        </div>
        <div class="name">asdfads</div>
        <div class="tag">#KarSallam</div>
        <p></p>
    </div>
</li>